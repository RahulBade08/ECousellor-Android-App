package com.admission.counsellor.ui.college;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.admission.counsellor.R;
import com.admission.counsellor.model.College;
import com.admission.counsellor.model.ShortlistRequest;
import com.admission.counsellor.model.ViewEventRequest;
import com.admission.counsellor.network.RetrofitClient;
import com.admission.counsellor.viewmodel.CollegeViewModel;
import com.admission.counsellor.viewmodel.StudentViewModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.chip.Chip;
import com.google.android.material.snackbar.Snackbar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Shows full college details.
 *
 * CHANGES vs original:
 *  1. Fires a silent view event to counselling backend on load
 *  2. Has a shortlist/bookmark button — fires shortlist event on tap
 *  3. Shows college info card (address, district, funding type)
 *
 * SETUP in fragment_college_detail.xml:
 *  Add these views if not already present:
 *  - MaterialToolbar       id="toolbar"
 *  - TextView              id="tv_college_name"
 *  - TextView              id="tv_college_code"
 *  - TextView              id="tv_address"
 *  - TextView              id="tv_district"
 *  - TextView              id="tv_funding_type"
 *  - TextView              id="tv_intake"
 *  - RecyclerView          id="recycler_courses"
 *  - Button / ImageButton  id="btn_shortlist"   ← NEW
 *  - ProgressBar           id="progress_bar"
 */
public class CollegeDetailFragment extends Fragment {

    private CollegeViewModel collegeViewModel;
    private StudentViewModel studentViewModel;  // to get student's own percentile/category

    // State — passed from CollegeResultAdapter via Bundle
    private String collegeCode;
    private String courseCode;          // which branch the student tapped on (may be null)
    private boolean isShortlisted = false;

    private Button btnShortlist;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_college_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        collegeViewModel = new ViewModelProvider(requireActivity()).get(CollegeViewModel.class);
        studentViewModel = new ViewModelProvider(requireActivity()).get(StudentViewModel.class);

        // Get args passed from results list
        if (getArguments() != null) {
            collegeCode = getArguments().getString("collegeCode");
            courseCode  = getArguments().getString("courseCode");  // may be null
        }

        MaterialToolbar toolbar = view.findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> Navigation.findNavController(view).popBackStack());

        btnShortlist = view.findViewById(R.id.btn_shortlist);

        // Observe college data
        collegeViewModel.getSelectedCollege().observe(getViewLifecycleOwner(), college -> {
            if (college == null) return;
            bindCollegeData(view, college);
        });

        // Load college details
        if (collegeCode != null) {
            collegeViewModel.loadCollegeByCode(collegeCode);

            // ── Fire view event silently ────────────────────────────────────
            fireViewEvent(collegeCode, courseCode);
        }

        // Shortlist button
        if (btnShortlist != null) {
            btnShortlist.setOnClickListener(v -> toggleShortlist());
        }
    }

    private void bindCollegeData(View view, College college) {
        setText(view, R.id.tv_college_name, college.getCollegeName());
        setText(view, R.id.tv_college_code, "Code: " + college.getCollegeCode());
        setText(view, R.id.tv_address,      college.getAddress() != null ? college.getAddress() : "—");
        setText(view, R.id.tv_district,     "District: " + college.getDistrict());
        setText(view, R.id.tv_funding_type, college.getFundingType() != null ? college.getFundingType() : "—");
        setText(view, R.id.tv_intake,       "Total Intake: " + college.getTotalIntake());
    }

    private void setText(View root, int id, String text) {
        TextView tv = root.findViewById(id);
        if (tv != null) tv.setText(text);
    }

    // ── Fire view event (silent, no auth) ─────────────────────────────────────
    private void fireViewEvent(String collegeCode, String courseCode) {
        ViewEventRequest req = new ViewEventRequest(
                collegeCode,
                courseCode,
                studentViewModel.percentile > 0 ? studentViewModel.percentile : null,
                studentViewModel.selectedCategory,
                studentViewModel.selectedGender,
                studentViewModel.selectedAdmissionType
        );

        RetrofitClient.getInstance().getApiService()
                .recordCollegeView(req)
                .enqueue(new Callback<Void>() {
                    @Override public void onResponse(Call<Void> call, Response<Void> response) { /* silent */ }
                    @Override public void onFailure(Call<Void> call, Throwable t) { /* silent */ }
                });
    }

    // ── Shortlist toggle ──────────────────────────────────────────────────────
    private void toggleShortlist() {
        if (collegeCode == null || courseCode == null) {
            Snackbar.make(requireView(), "Please view a specific branch to shortlist.", Snackbar.LENGTH_SHORT).show();
            return;
        }

        isShortlisted = !isShortlisted;

        if (btnShortlist != null) {
            btnShortlist.setText(isShortlisted ? "✓ Shortlisted" : "☆ Shortlist");
        }

        if (isShortlisted) {
            // Build derived cap category code same as backend logic
            String capCode = derivedCapCategoryCode(
                    studentViewModel.selectedCategory,
                    studentViewModel.selectedGender,
                    studentViewModel.selectedAdmissionType
            );

            ShortlistRequest req = new ShortlistRequest(
                    collegeCode,
                    courseCode,
                    "",  // courseName — fill if available from args
                    studentViewModel.percentile > 0 ? studentViewModel.percentile : null,
                    studentViewModel.selectedCategory,
                    studentViewModel.selectedGender,
                    studentViewModel.selectedAdmissionType,
                    capCode
            );

            RetrofitClient.getInstance().getApiService()
                    .recordShortlist(req)
                    .enqueue(new Callback<Void>() {
                        @Override public void onResponse(Call<Void> call, Response<Void> r) {}
                        @Override public void onFailure(Call<Void> call, Throwable t) {}
                    });

            Snackbar.make(requireView(), "College shortlisted!", Snackbar.LENGTH_SHORT).show();
        }
    }

    // ── Derive capCategoryCode (mirrors backend StudentPredictionRequest logic) ─
    private String derivedCapCategoryCode(String category, String gender, String admissionType) {
        if ("EWS".equals(category) || "TFWS".equals(category)) return category;
        String prefix = "LADIES".equalsIgnoreCase(gender) ? "L" : "G";
        String suffix = "HOME".equalsIgnoreCase(admissionType) ? "H"
                : "OTHER".equalsIgnoreCase(admissionType) ? "O" : "S";
        String mid = normalizeCategory(category);
        return prefix + mid + suffix;
    }

    private String normalizeCategory(String cat) {
        if (cat == null) return "OPEN";

        String value = cat.toUpperCase().trim();

        switch (value) {
            case "OPEN":
                return "OPEN";

            case "OBC":
                return "OBC";

            case "SC":
                return "SC";

            case "ST":
                return "ST";

            case "NT1":
            case "NT-1":
            case "VJ":
                return "NT1";

            case "NT2":
            case "NT-2":
                return "NT2";

            case "NT3":
            case "NT-3":
                return "NT3";

            default:
                return value;
        }
    }
}
